module CompatResource
  VERSION = '12.10.5'
end
